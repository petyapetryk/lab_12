let x = prompt("Eneter number");

if (x % 2 == 0)
{
    console.log("Число є парним");
} else if (x % 3 === 0) 
{
    console.log("Число є не парним");
}