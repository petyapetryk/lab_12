let isAdult = prompt("Скільки вам років?");

if (isAdult >= 18)
{
    console.log("Ви досягли повноліття");
} else {
    console.log("Ви ще не досягли повноліття");
}